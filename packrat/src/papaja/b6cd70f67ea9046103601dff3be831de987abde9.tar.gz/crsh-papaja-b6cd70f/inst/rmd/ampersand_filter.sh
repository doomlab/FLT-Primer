#!/bin/bash
Rscript --vanilla -e "papaja:::ampersand_filter()"
